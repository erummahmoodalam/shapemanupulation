/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author OK Computers
 */

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author OK Computers
 */
import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class Plus extends JFrame {
    public static void main(String[] args) {
        arrowworking ar = new arrowworking();
    }}
        class arrowworking extends JFrame{
            public arrowworking(){
     JFrame window =new JFrame ("plusmanupulation");
     window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     window.setSize(700,700);
     window.setResizable(false);
     JPanel pan = new JPanel ();
     pan.setBackground(new Color(0,153,153));
     pan.setLayout(null);
     pan.setBorder(BorderFactory.createLineBorder(Color.black));
     window.setContentPane(pan);
     JButton sqr1 = new JButton ();
     JButton sqr2 = new JButton ();
     JButton sqr3 = new JButton () ;
     JButton sqr4 = new JButton () ;
     JButton btn1 = new JButton ("RIGHT") ;
     btn1.setBounds(150,600,100,50);
     pan.add(btn1);
     JButton btn2 = new JButton ("LEFT") ;
     btn2.setBounds(250,600,100,50);
     pan.add(btn2);
     JButton btn3 = new JButton ("COMBINE") ;
     btn3.setBounds(350,600,100,50);
     pan.add(btn3);
    
     JButton ret = new JButton ("RETURN");
     ret.setBounds(550,600,100,30);
     pan.add(ret);
     ret.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            ret.setEnabled(false);
            new menu().setVisible(true);;
         }});
     sqr1.setBounds(40,300,50,50);
     sqr1.setBackground (Color.black);
     sqr1.setEnabled(false);
     sqr2.setBounds(390,300,50,50);
     sqr2.setBackground(Color.black);
     sqr2.setEnabled(false);
     sqr3.setBounds(40,40,50,50);
     sqr3.setBackground(Color.black);
     sqr3.setEnabled(false);
     sqr4.setBounds(40,500,50,50);
     sqr4.setBackground(Color.black);
     sqr4.setEnabled(false);
     pan.add(sqr1);
     pan.add(sqr2);
     pan.add(sqr3);
     pan.add(sqr4);
     window.setVisible(true);
     btn1.addActionListener(new ActionListener(){
      @Override
      synchronized public void actionPerformed(ActionEvent e) {
        btn1.setEnabled(false);

        Thread thread = new Thread() {
        @Override
        public void run() {
             synchronized(this) {
            Point point = sqr1.getLocation();
            Point point2 = sqr2.getLocation();
            Point point3 = sqr4.getLocation();
                while (point.x!=201) {
                    sqr1.setLocation(point.x,point.y);
                    point.x++ ;
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException ex) {}
                }while (point3.x!=225) {
                    sqr4.setLocation(point3.x,point3.y);
                    point3.x++ ;
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException ex) {}
                }
                
                    while(sqr2.getLocation().x != 250){/* wait */}
                    point = sqr1.getLocation();
                    point2 = sqr2.getLocation();
                    while (point.y!=90) {
                        sqr2.setLocation(point2.x,point2.y);
                        sqr1.setLocation(point.x,point.y);
                        point.y-- ;
                        point2.y-- ;
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException ex) {}
                    }
              }}
            };
            thread.start();
            }
        });
     btn2.addActionListener(new ActionListener(){
      @Override
      synchronized public void actionPerformed(ActionEvent e) {
        btn2.setEnabled(false);
        Thread thread = new Thread() {
        Point point = sqr2.getLocation();
        Point point1 = sqr1.getLocation();
        Point point2=sqr4.getLocation();
        @Override
        public void run() {
             synchronized(sqr3) {
                while (point.x!=249) {
                    sqr2.setLocation(point.x,point.y);
                    point.x-- ;
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException ex) {}
                }
                while (point2.y!=350) {
                    sqr4.setLocation(point2.x,point2.y);
                    point2.y-- ;
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException ex) {}
                }
                    while(sqr1.getLocation().x != sqr2.getLocation().x -50){/* wait */}
                    
                     point = sqr2.getLocation();
                     point1 = sqr1.getLocation();
                     point2 = sqr4.getLocation();
                     
                    while (point.y!=90) {
                        sqr2.setLocation(point.x,point.y);
                        sqr1.setLocation(point1.x,point1.y);
                        sqr4.setLocation(point2.x,point2.y);
                        point.y-- ;
                        point1.y-- ;
                        point2.y--;
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException ex) {}
                    }
                }}
            };
            thread.start();
            }
        });
    
     btn3.addActionListener(new ActionListener(){
      @Override
     synchronized public void actionPerformed(ActionEvent e) {
        btn3.setEnabled(false);
        Thread thread = new Thread() {
           
        Point p3 = sqr3.getLocation();
        Point p1 = sqr1.getLocation();
        Point p2 = sqr2.getLocation();
        Point p4 = sqr4.getLocation();
        @Override
        public void run() {
             synchronized(sqr4) {
                while (p3.x!=225) {
                    sqr3.setLocation(p3.x,40);
                    p3.x++ ;
                    try {                          
                        Thread.sleep(20);
                    } catch (InterruptedException ex) {}
                }
                    while(sqr1.getLocation().y != 91){System.out.println();/* wait */} 
                    
                            p3 = sqr3.getLocation();
                            p1 = sqr1.getLocation();
                            p2 = sqr2.getLocation();
                            p4 = sqr4.getLocation();
                    while (p3.x!=700) {
                        sqr3.setLocation(p3.x,p3.y);
                        sqr1.setLocation(p1.x,p1.y);
                        sqr2.setLocation(p2.x,p2.y);
                        sqr4.setLocation(p4.x,p4.y);
                        p3.x++ ;
                        p1.x++ ;
                        p2.x++ ;
                        p4.x++;
                        try {             
                            Thread.sleep(20);
                        } catch (InterruptedException ex) {}
                    }
                }}
            };
            thread.start();
            }
        });
     /*btn4.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            btn4.setEnabled(false);
            btn1.doClick();
            btn2.doClick();
            btn3.doClick();
         }
     });*/ 
    }
}
