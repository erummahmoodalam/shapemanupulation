/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author OK Computers
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class circle{public static void main(String[] args) {
        circleworking frame = new circleworking();
        frame.setVisible(true);
    }
}
class circleworking extends JFrame {
    private static final int WIDTH = 900;
    private static final int HEIGHT = 800;
    
    private int x;
    private int y;
    private Color color;

    public circleworking() {
        x = 60;
        y = 60;
        
        color = Color.black;

        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel canvasPanel = new JPanel() {
            
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(color);
                g.fillOval(x, y, 50, 50);
            }
        };
        add(canvasPanel, BorderLayout.CENTER);
        canvasPanel.setBackground(new Color(0,153,153));
        JPanel buttonPanel = new JPanel();
        add(buttonPanel, BorderLayout.SOUTH);

        JButton moveRightButton = new JButton("Move Right");
        moveRightButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                x += 10;
                repaint();
            }
        });
        buttonPanel.add(moveRightButton);

        JButton moveLeftButton = new JButton("Move Left");
        moveLeftButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                x -= 10;
                repaint();
            }
        });
        buttonPanel.add(moveLeftButton);

        JButton moveUpButton = new JButton("Move Up");
        moveUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                y -= 10;
                repaint();
            }
        });
        buttonPanel.add(moveUpButton);
  
        JButton moveDownButton = new JButton("Move Down");
        moveDownButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                y += 10;
                repaint();
            }
        });
        buttonPanel.add(moveDownButton);

        JButton changeColorButton = new JButton("Change Color");
        changeColorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                color = new Color((int) (Math.random() * 0x1000000));
                repaint();
            }
        });
        JButton ret = new JButton ("RETURN");
     ret.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
            ret.setEnabled(false);
            new menu().setVisible(true);
         }});
          buttonPanel.add(ret);
    }
}
    