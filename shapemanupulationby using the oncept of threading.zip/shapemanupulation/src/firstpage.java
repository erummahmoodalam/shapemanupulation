/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author OK Computers
 */

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory; 
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
public class firstpage {
     public static void main(String[] args) { 
         x obj = new x();
     }}
class x extends JFrame{
    public x(){
        JButton rec = new JButton("SQUARE");
        rec.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e){
            throw new UnsupportedOperationException("not supported yet. ");
             new recworking();  
        }
        });
     JPanel pan = new JPanel ();
     pan.setBackground(Color.pink);
     pan.setLayout(null);
     setVisible(true);
     setSize(600,600);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }

}
